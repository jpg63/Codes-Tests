/*
  Using the BNO080 IMU
  By: Nathan Seidle
  SparkFun Electronics
  Date: December 21st, 2017
  License: This code is public domain but you buy me a beer if you use this and we meet someday (Beerware license).

  Feel like supporting our work? Buy a board from SparkFun!
  https://www.sparkfun.com/products/14586

  This example shows how to output the i/j/k/real parts of the rotation vector.
  https://en.wikipedia.org/wiki/Quaternions_and_spatial_rotation

  It takes about 1ms at 400kHz I2C to read a record from the sensor, but we are polling the sensor continually
  between updates from the sensor. Use the interrupt pin on the BNO080 breakout to avoid polling.

  Hardware Connections:
  Attach the Qwiic Shield to your Arduino/Photon/ESP32 or other
  Plug the sensor onto the shield
  Serial.print it out at 9600 baud to serial monitor.
*/

#define SDA_PIN 27
#define SCL_PIN 32
#define POWER_PIN 12
#define POWER_PIN_STATE HIGH 
#define INT_PIN 26

#include <Wire.h>

#include "SparkFun_BNO080_Arduino_Library.h"
BNO080 myIMU;

// indicators of new data availability
volatile byte newQuat = 0;
volatile byte newLinAcc = 0;
volatile byte newint = 0;
// internal copies of the IMU data
float ax, ay, az, qx, qy, qz, qw; // (qx, qy, qz, qw = i,j,k, real)
byte linAccuracy = 0;
float quatRadianAccuracy = 0;
byte quatAccuracy = 0;
// pin used for interrupts
//byte imuINTPin = 26;

//Given an accuracy number, print what it means
void printAccuracyLevel(byte accuracyNumber)
{
  if (accuracyNumber == 0) Serial.println(F("Unreliable"));
  else if (accuracyNumber == 1) Serial.println(F("Low"));
  else if (accuracyNumber == 2) Serial.println(F("Medium"));
  else if (accuracyNumber == 3) Serial.println(F("High"));
}

// This function is called whenever an interrupt is detected by the arduino
void interrupt_handler()
{
  newint = 1;
  // code snippet from ya-mouse
   switch (myIMU.getReadings())
   {
      case SENSOR_REPORTID_LINEAR_ACCELERATION: {
        newLinAcc = 1;
      }
      break;

      case SENSOR_REPORTID_ROTATION_VECTOR:
      case SENSOR_REPORTID_GAME_ROTATION_VECTOR: {
         newQuat = 1;
      }
      break;
      default:
         // Unhandled Input Report
         break;
   }
}

void setup()
{
  Serial.begin(115200);
  delay(5000);
  Serial.println();
  Serial.println("BNO080 Read Example");

  pinMode(POWER_PIN, OUTPUT); 
  digitalWrite(POWER_PIN, POWER_PIN_STATE);     // turn on POWER

//  Wire.begin();

  //Are you using a ESP? Check this issue for more information: https://github.com/sparkfun/SparkFun_BNO080_Arduino_Library/issues/16
//  //=================================
//  delay(100); //  Wait for BNO to boot
//  // Start i2c and BNO080
//  Wire.flush();   // Reset I2C
//  IMU.begin(BNO080_DEFAULT_ADDRESS, Wire);
//  Wire.begin(4, 5); 
//  Wire.setClockStretchLimit(4000);
//  //=================================

  delay(100);
  Wire.flush();
  Wire.begin (SDA_PIN, SCL_PIN);
//  myIMU.begin(0x4A, Wire);

  if (myIMU.begin(0x4A, Wire) == false)  //, INT_PIN) == false)
  {
    Serial.println("BNO080 not detected at default I2C address. Check your jumpers and the hookup guide. Freezing...");
    while (1);
  }

  Wire.setClock(400000); //Increase I2C data rate to 400kHz

  // prepare interrupt on falling edge (= signal of new data available)
  attachInterrupt(digitalPinToInterrupt(INT_PIN), interrupt_handler, FALLING);
  // enable interrupts right away to not miss first reports
  interrupts();

  myIMU.enableLinearAccelerometer(50);  // m/s^2 no gravity, data update every 50 ms
  myIMU.enableRotationVector(50); //Send data update every 50ms

  Serial.println(F("Rotation vector enabled"));
  Serial.println(F("Output in form i, j, k, real, accuracy"));
}

void loop()
{
  if(Serial.available())
  {
  byte incoming = Serial.read();

  if(incoming == 't')
  {
    myIMU.tareAllAxes(); //tare
    myIMU.saveTare(); //save tare
    delay(1);
    }
  }
  
  //Look for reports from the IMU
  if (myIMU.dataAvailable() == true)
  {
    float quatI = myIMU.getQuatI();
    float quatJ = myIMU.getQuatJ();
    float quatK = myIMU.getQuatK();
    float quatReal = myIMU.getQuatReal();
    float quatRadianAccuracy = myIMU.getQuatRadianAccuracy();

   /*     w = real
    *     x = i
    *     y = j
    *     z = k
    */

    Serial.print(F(", W : "));
    Serial.print(quatReal, 2);
    Serial.print(F(", x : "));
    Serial.print(quatI, 2);
    Serial.print(F(", y: "));
    Serial.print(quatJ, 2);
    Serial.print(F(", z: "));
    Serial.print(quatK, 2);
    Serial.print(F(","));
    Serial.print(quatRadianAccuracy, 2);
    Serial.print(F(","));

    Serial.println();
  }

  if (newint) {
    newint = 0;
    Serial.println("Doing other things");
  }

  delay(10); //You can do many other things. Interrupt handler will retrieve latest data

  // If new data on LinAcc sensor, retrieve it from the library memory
  if(newLinAcc) {
    myIMU.getLinAccel(ax, ay, az, linAccuracy);
    newLinAcc = 0; // mark data as read
    Serial.print(F("acc :"));
    Serial.print(ax, 2);
    Serial.print(F(","));
    Serial.print(ay, 2);
    Serial.print(F(","));
    Serial.print(az, 2);
    Serial.print(F(","));
    Serial.print(az, 2);
    Serial.print(F(","));
    printAccuracyLevel(linAccuracy);
  }
  // If new data on Rotation Vector sensor, retrieve it from the library memory
  if(newQuat) {
    myIMU.getQuat(qx, qy, qz, qw, quatRadianAccuracy, quatAccuracy);
    newQuat = 0; // mark data as read
    Serial.print(F("quat:"));
    Serial.print(qx, 2);
    Serial.print(F(","));
    Serial.print(qy, 2);
    Serial.print(F(","));
    Serial.print(qz, 2);
    Serial.print(F(","));
    Serial.print(qw, 2);
    Serial.print(F(","));
    printAccuracyLevel(quatAccuracy);
  }





}
